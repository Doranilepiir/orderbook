export default function KillFeed() {
    return (
      <div>
        <button type= "button"  className='kill-feed'>Kill Feed</button>
      </div>
    );
  }
  