export default function SelectBox() {
    return (
      <div className='b'>
        <select name="" id="" className='select-box'>
          <option
        value="0.5">Group 0.5</option>
        <option
        value="1.0">Group 1.0</option>
        <option
        value="2.5">Group 2.5</option>


        </select>
      </div>
    );
  }
  