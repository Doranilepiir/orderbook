import React, { useContext, useState, useEffect, ReactNode } from "react";

const Context = React.createContext({});

interface ContextProps {
 children?: ReactNode;
}

export function useApp() {
  return useContext(Context);
}

export const Provider = ({ children }: ContextProps) => {
// Create WebSocket connection.
const socket = new WebSocket('wss://www.cryptofacilities.com/ws/v1');

// Connection opened
socket.addEventListener('open', function (event) {
    socket.send('{"event":"subscribe","feed":"book_ui_1","product_ids":["PI_XBTUSD"]}');
});

// Listen for messages
socket.addEventListener('message', function (event) {
    console.log('Message from server ', event.data);
});
  const a = 20;
  return (
    <Context.Provider
      value={{a}}
    >
      {children}
    </Context.Provider>
  );
};