export default function TogggleFeed() {
    return (
      <div >
        <button type = "button" className='toggle-feed' >Toggle Feed</button>
      </div>
    );
  }
  